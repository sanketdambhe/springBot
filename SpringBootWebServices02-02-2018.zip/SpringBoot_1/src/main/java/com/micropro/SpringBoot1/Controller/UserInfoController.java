/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Controller;

/**
 *
 * @author cdharmik
 */
import com.micropro.SpringBoot1.Models.AdUserMst;
import com.micropro.SpringBoot1.Models.InLocMst;
import com.micropro.SpringBoot1.Repository.UserInfoRepository;
import java.util.List;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@RequestMapping("/micropro")
@CrossOrigin(origins = "http://192.168.0.121:4200")
public class UserInfoController {

    @Autowired
    UserInfoRepository hmerep;

    @GetMapping("/abc/{id}/{name}")
    public String testGetReq(@PathVariable() int id, @PathVariable String name) {
        return name + " " + id;
    }

    @GetMapping("/getLoc")
    public List<AdUserMst> getData() {
        return hmerep.getUserData();
    }

    @GetMapping("/getLocByid/{id}")
    public AdUserMst getLocByCod(@PathVariable() Long id) {
        System.err.println("Id -- " + id);
        return hmerep.getUserById(id);
    }

    @GetMapping("/getMsg")
    public String getMessage() {
        return "Hello" + hmerep.getMessage();
    }

    @PostMapping("/InsertLoc")
    public ResponseEntity<AdUserMst> createLocation(@RequestBody AdUserMst ilnn) {
        hmerep.createUser(ilnn);
        return new ResponseEntity<AdUserMst>(ilnn, HttpStatus.OK);
    }

    @PutMapping("/updateUsr/{id}")
    public AdUserMst updateUser(@RequestBody AdUserMst ilnn, @PathVariable() Long id) {
        System.err.println("id = " + id);
        System.err.println("Name : " + ilnn.getName());
        return hmerep.updateUserDetails(ilnn);
    }

    @DeleteMapping("/deleteUsr/{id}")
    public AdUserMst deleteUser(@RequestBody AdUserMst ilnn, @PathVariable() Long id) {
        System.err.println("id = " + id);
        return hmerep.deleteUser(id);
    }

}
