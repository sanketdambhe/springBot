/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Models;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author cdharmik
 */
@Entity
@Table(name = "gm_dept_mst")
@NamedQueries({
    @NamedQuery(name = "GmDeptMst.findAll", query = "SELECT g FROM GmDeptMst g")
    , @NamedQuery(name = "GmDeptMst.findByOrgid", query = "SELECT g FROM GmDeptMst g WHERE g.orgid = :orgid")
    , @NamedQuery(name = "GmDeptMst.findById", query = "SELECT g FROM GmDeptMst g WHERE g.id = :id")
    , @NamedQuery(name = "GmDeptMst.findByCode", query = "SELECT g FROM GmDeptMst g WHERE g.code = :code")
    , @NamedQuery(name = "GmDeptMst.findByName", query = "SELECT g FROM GmDeptMst g WHERE g.name = :name")
    , @NamedQuery(name = "GmDeptMst.findByType", query = "SELECT g FROM GmDeptMst g WHERE g.type = :type")
    , @NamedQuery(name = "GmDeptMst.findByStoreLocId", query = "SELECT g FROM GmDeptMst g WHERE g.storeLocId = :storeLocId")
    , @NamedQuery(name = "GmDeptMst.findByAprvlGroup", query = "SELECT g FROM GmDeptMst g WHERE g.aprvlGroup = :aprvlGroup")
    , @NamedQuery(name = "GmDeptMst.findByDefunct", query = "SELECT g FROM GmDeptMst g WHERE g.defunct = :defunct")
    , @NamedQuery(name = "GmDeptMst.findByCreatedOn", query = "SELECT g FROM GmDeptMst g WHERE g.createdOn = :createdOn")
    , @NamedQuery(name = "GmDeptMst.findByCreatedBy", query = "SELECT g FROM GmDeptMst g WHERE g.createdBy = :createdBy")
    , @NamedQuery(name = "GmDeptMst.findByUpdatedOn", query = "SELECT g FROM GmDeptMst g WHERE g.updatedOn = :updatedOn")
    , @NamedQuery(name = "GmDeptMst.findByUpdatedBy", query = "SELECT g FROM GmDeptMst g WHERE g.updatedBy = :updatedBy")
    , @NamedQuery(name = "GmDeptMst.findByVersionId", query = "SELECT g FROM GmDeptMst g WHERE g.versionId = :versionId")})
public class GmDeptMst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "orgid")
    private long orgid;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Column(name = "type")
    private Character type;
    @Column(name = "store_loc_id")
    private BigInteger storeLocId;
    @Column(name = "aprvl_group")
    private BigInteger aprvlGroup;
    @Basic(optional = false)
    @NotNull
    @Column(name = "defunct")
    private Character defunct;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_by")
    private long createdBy;
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;
    @Column(name = "updated_by")
    private BigInteger updatedBy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "version_id")
    private long versionId;

    public GmDeptMst() {
    }

    public GmDeptMst(Long id) {
        this.id = id;
    }

    public GmDeptMst(Long id, long orgid, String code, String name, Character type, Character defunct, Date createdOn, long createdBy, long versionId) {
        this.id = id;
        this.orgid = orgid;
        this.code = code;
        this.name = name;
        this.type = type;
        this.defunct = defunct;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.versionId = versionId;
    }

    public long getOrgid() {
        return orgid;
    }

    public void setOrgid(long orgid) {
        this.orgid = orgid;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Character getType() {
        return type;
    }

    public void setType(Character type) {
        this.type = type;
    }

    public BigInteger getStoreLocId() {
        return storeLocId;
    }

    public void setStoreLocId(BigInteger storeLocId) {
        this.storeLocId = storeLocId;
    }

    public BigInteger getAprvlGroup() {
        return aprvlGroup;
    }

    public void setAprvlGroup(BigInteger aprvlGroup) {
        this.aprvlGroup = aprvlGroup;
    }

    public Character getDefunct() {
        return defunct;
    }

    public void setDefunct(Character defunct) {
        this.defunct = defunct;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(long createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public BigInteger getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(BigInteger updatedBy) {
        this.updatedBy = updatedBy;
    }

    public long getVersionId() {
        return versionId;
    }

    public void setVersionId(long versionId) {
        this.versionId = versionId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GmDeptMst)) {
            return false;
        }
        GmDeptMst other = (GmDeptMst) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.micropro.SpringBoot1.Models.GmDeptMst[ id=" + id + " ]";
    }
    
}
