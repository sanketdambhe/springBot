/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Repository;

import com.micropro.SpringBoot1.Models.InLocMst;
import java.util.List;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author cdharmik
 */
@Repository
@Transactional
public class LocMstRepository {

    @Autowired
    EntityManager em;

    public List<InLocMst> getAllLocDeptMst() {
        return em.createQuery("select t from InLocMst t").getResultList();
    }

    public InLocMst getLocDepMstByCod(Long id) {
        return em.find(InLocMst.class, id);
    }

    public InLocMst createLocMst(InLocMst ilm) {
        em.persist(ilm);
        return ilm;
    }

    public InLocMst putLocMster(InLocMst ilnm) {
        em.merge(ilnm);
        return ilnm;
    }

    public InLocMst deleteLocMst(InLocMst ilmn) {
        em.remove(em.merge(ilmn));
        return ilmn;
    }

}
