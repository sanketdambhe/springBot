/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Repository;

import com.micropro.SpringBoot1.Models.AdUserMst;
import com.micropro.SpringBoot1.Models.InLocMst;
import java.util.List;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author cdharmik
 */
@Repository
@Transactional
public class UserInfoRepository {

    @Autowired
    EntityManager em;

    public List<AdUserMst> getUserData() {
        return em.createQuery("select t from AdUserMst t").getResultList();
    }

    public AdUserMst getUserById(Long id) {
        return em.find(AdUserMst.class, id);
    }

    public AdUserMst createUser(AdUserMst iln) {
        em.persist(iln);
        return iln;
    }

    public AdUserMst updateUserDetails(AdUserMst ilnn) {
        System.out.println("findedAdUserMst update = " + ilnn.getName());
        System.out.println("findedAdUserMst wiht id  update = " + ilnn.getId());       
        em.merge(ilnn);
        return ilnn;
    }

    public AdUserMst deleteUser(Long id) {
        AdUserMst findedAdUserMst = em.find(AdUserMst.class, id);
        System.out.println("findedAdUserMst = " + findedAdUserMst);
        System.out.println("findedAdUserMst wiht id = " + findedAdUserMst.getId());
        em.remove(em.merge(findedAdUserMst));
        return findedAdUserMst;
    }

    public String getMessage() {
        return "Get Message ";
    }

}
