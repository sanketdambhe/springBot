/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Controller;

import com.micropro.SpringBoot1.Models.GmDeptMst;
import com.micropro.SpringBoot1.Models.InLocMst;
import com.micropro.SpringBoot1.Repository.GmDepMstRepos;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

/**
 *
 * @author cdharmik
 */
@RestController
@RequestMapping("/gmDepMst")
@CrossOrigin(origins = "http://192.168.0.121:4200")
public class GMDepMstController {

    @Autowired
    GmDepMstRepos lmrep;

    @GetMapping("/getDepMst")
    public List<GmDeptMst> getLoc() {
        return lmrep.getAllGmDeptMst();
    }

    @GetMapping("/getDepMstId/{id}")
    public GmDeptMst getGmDepById(@PathVariable() Long id) {
        return lmrep.getGmDepMstByCod(id);
    }

    @PostMapping("/postDeoMst")
    public ResponseEntity<GmDeptMst> postGmDepMst(@RequestBody GmDeptMst gmst) {
        lmrep.postGmDepMstData(gmst);
        return new ResponseEntity<GmDeptMst>(gmst, HttpStatus.OK);
    }

    @PutMapping("/putDepMst/{id}")
    public GmDeptMst putGmDepMst(@RequestBody GmDeptMst gmps, @PathVariable int id) {
        lmrep.putGMDepMst(gmps);
        return gmps;
    }

    @DeleteMapping("/deleteDepMst/{id}")
    public GmDeptMst deleteGmDepMst(@RequestBody GmDeptMst gmps, @PathVariable int id) {
        System.err.println("Name : " + gmps.getName());
        lmrep.deleteDepMst(gmps);
        return gmps;
    }

    @DeleteMapping("/testDelete/{code}")
    public String testDelete(@RequestBody GmDeptMst gmd, @PathVariable String code) {
        lmrep.deletCode(gmd);
        return "Hello" + code;
    }

}
