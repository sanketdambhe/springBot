/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.micropro.SpringBoot1.Models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author cdharmik
 */
@Entity
@Table(name = "in_loc_mst")
@NamedQueries({
    @NamedQuery(name = "InLocMst.findAll", query = "SELECT i FROM InLocMst i")
    , @NamedQuery(name = "InLocMst.findByOrgid", query = "SELECT i FROM InLocMst i WHERE i.orgid = :orgid")
    , @NamedQuery(name = "InLocMst.findByOprid", query = "SELECT i FROM InLocMst i WHERE i.oprid = :oprid")
    , @NamedQuery(name = "InLocMst.findById", query = "SELECT i FROM InLocMst i WHERE i.id = :id")
    , @NamedQuery(name = "InLocMst.findByCode", query = "SELECT i FROM InLocMst i WHERE i.code = :code")
    , @NamedQuery(name = "InLocMst.findByName", query = "SELECT i FROM InLocMst i WHERE i.name = :name")
    , @NamedQuery(name = "InLocMst.findByType", query = "SELECT i FROM InLocMst i WHERE i.type = :type")
    , @NamedQuery(name = "InLocMst.findByAllowIssue", query = "SELECT i FROM InLocMst i WHERE i.allowIssue = :allowIssue")
    , @NamedQuery(name = "InLocMst.findByAllowPurchase", query = "SELECT i FROM InLocMst i WHERE i.allowPurchase = :allowPurchase")
    , @NamedQuery(name = "InLocMst.findByAllowTransfer", query = "SELECT i FROM InLocMst i WHERE i.allowTransfer = :allowTransfer")
    , @NamedQuery(name = "InLocMst.findByHodUserid", query = "SELECT i FROM InLocMst i WHERE i.hodUserid = :hodUserid")
    , @NamedQuery(name = "InLocMst.findByAprvlGroup", query = "SELECT i FROM InLocMst i WHERE i.aprvlGroup = :aprvlGroup")
    , @NamedQuery(name = "InLocMst.findByEmail", query = "SELECT i FROM InLocMst i WHERE i.email = :email")
    , @NamedQuery(name = "InLocMst.findByMobile", query = "SELECT i FROM InLocMst i WHERE i.mobile = :mobile")
    , @NamedQuery(name = "InLocMst.findByAddress", query = "SELECT i FROM InLocMst i WHERE i.address = :address")
    , @NamedQuery(name = "InLocMst.findByDefunct", query = "SELECT i FROM InLocMst i WHERE i.defunct = :defunct")
    , @NamedQuery(name = "InLocMst.findByCreatedOn", query = "SELECT i FROM InLocMst i WHERE i.createdOn = :createdOn")
    , @NamedQuery(name = "InLocMst.findByCreatedBy", query = "SELECT i FROM InLocMst i WHERE i.createdBy = :createdBy")
    , @NamedQuery(name = "InLocMst.findByUpdatedOn", query = "SELECT i FROM InLocMst i WHERE i.updatedOn = :updatedOn")
    , @NamedQuery(name = "InLocMst.findByUpdatedBy", query = "SELECT i FROM InLocMst i WHERE i.updatedBy = :updatedBy")
    , @NamedQuery(name = "InLocMst.findByVersionId", query = "SELECT i FROM InLocMst i WHERE i.versionId = :versionId")})
public class InLocMst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @JsonIgnore
    @Column(name = "orgid")
    private long orgid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "oprid")
    private long oprid;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Column(name = "type")
    private Character type;
    @Basic(optional = false)
    @NotNull
    @Column(name = "allowIssue")
    private Character allowIssue;
    @Column(name = "allowPurchase")
    private Character allowPurchase;
    @Basic(optional = false)
    @NotNull
    @Column(name = "allowTransfer")
    private Character allowTransfer;
    @Column(name = "hod_userid")
    private BigInteger hodUserid;
    @Column(name = "aprvl_group")
    private BigInteger aprvlGroup;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "email")
    private String email;
    @Size(max = 25)
    @Column(name = "mobile")
    private String mobile;
    @Size(max = 200)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @NotNull
    @Column(name = "defunct")
    private Character defunct;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;
    @Basic(optional = false)
    @NotNull
    @Column(name = "created_by")
    @JsonIgnore
    private long createdBy;
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @JsonIgnore
    private Date updatedOn;
    @Column(name = "updated_by")
    @JsonIgnore
    private BigInteger updatedBy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "version_id")
    @JsonIgnore
    private long versionId;

    @PrePersist
    protected void preCreate() {
        this.createdOn = new Date();
        this.versionId = 0;
        this.orgid = 1;
    }

    public InLocMst() {
    }

    public InLocMst(Long id) {
        this.id = id;
    }

    public InLocMst(Long id, long orgid, long oprid, String code, String name, Character type, Character allowIssue, Character allowTransfer, Character defunct, Date createdOn, long createdBy, long versionId) {
        this.id = id;
        this.orgid = orgid;
        this.oprid = oprid;
        this.code = code;
        this.name = name;
        this.type = type;
        this.allowIssue = allowIssue;
        this.allowTransfer = allowTransfer;
        this.defunct = defunct;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.versionId = versionId;
    }

    public long getOrgid() {
        return orgid;
    }

    public void setOrgid(long orgid) {
        this.orgid = orgid;
    }

    public long getOprid() {
        return oprid;
    }

    public void setOprid(long oprid) {
        this.oprid = oprid;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Character getType() {
        return type;
    }

    public void setType(Character type) {
        this.type = type;
    }

    public Character getAllowIssue() {
        return allowIssue;
    }

    public void setAllowIssue(Character allowIssue) {
        this.allowIssue = allowIssue;
    }

    public Character getAllowPurchase() {
        return allowPurchase;
    }

    public void setAllowPurchase(Character allowPurchase) {
        this.allowPurchase = allowPurchase;
    }

    public Character getAllowTransfer() {
        return allowTransfer;
    }

    public void setAllowTransfer(Character allowTransfer) {
        this.allowTransfer = allowTransfer;
    }

    public BigInteger getHodUserid() {
        return hodUserid;
    }

    public void setHodUserid(BigInteger hodUserid) {
        this.hodUserid = hodUserid;
    }

    public BigInteger getAprvlGroup() {
        return aprvlGroup;
    }

    public void setAprvlGroup(BigInteger aprvlGroup) {
        this.aprvlGroup = aprvlGroup;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Character getDefunct() {
        return defunct;
    }

    public void setDefunct(Character defunct) {
        this.defunct = defunct;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(long createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public BigInteger getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(BigInteger updatedBy) {
        this.updatedBy = updatedBy;
    }

    public long getVersionId() {
        return versionId;
    }

    public void setVersionId(long versionId) {
        this.versionId = versionId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InLocMst)) {
            return false;
        }
        InLocMst other = (InLocMst) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.micropro.SpringBoot1.Models.InLocMst[ id=" + id + " ]";
    }

}
